﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab2_2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_2.Tests
{
    [TestClass()]
    public class LogicTests
    {
        [TestMethod()]
        public void CheckTest1()
        {
            var sa = "asb";
            var sb = "";
            var message = Logic.Check(sa, sb);
            Assert.AreEqual("Вы ввели не правильное значение", message);
        }

        [TestMethod()]
        public void CheckTest2()
        {
            var sa = "";
            var sb = "";
            var message = Logic.Check(sa, sb);
            Assert.AreEqual("Вы ввели не правильное значение", message);
        }

        [TestMethod()]
        public void CheckTest3()
        {
            var sa = "15";
            var sb = "";
            var message = Logic.Check(sa, sb);
            Assert.AreEqual("Вы ввели не правильное значение", message);
        }

        [TestMethod()]
        public void CheckTest4()
        {
            var sa = "15";
            var sb = "15";
            var message = Logic.Check(sa, sb);
            Assert.AreEqual("Разрезан на квадрат размером 15\nКоличество квадратов: 1\n", message);
        }

        [TestMethod()]
        public void CheckTest5()
        {
            var sa = "5";
            var sb = "3";
            var message = Logic.Check(sa, sb);
            Assert.AreEqual("Разрезан на квадрат размером 3\nПрямоугольник размером: 2 3\n"
                + "Разрезан на квадрат размером 2\nПрямоугольник размером: 2 1\n"
                + "Разрезан на квадрат размером 1\nПрямоугольник размером: 1 1\n"
                + "Разрезан на квадрат размером 1\nКоличество квадратов: 4\n", message);
        }
    }
}